#include<stdio.h>

int main(){
    // Naive way to create 4 ints
    // int marks1, marks2, marks3, marks4;
    // marks1 = 34;
    // marks2 = 45;
    // marks3 = 67;
    // marks4 = 87;
    int marks[4];
    marks[0] = 34;
    marks[1] = 45;
    marks[2] = 34;
    marks[3] = 67;


    return 0;
}