# include<stdio.h>
int main()
{
// int x=10;
// if (x==11)
// {
//     printf("i am 11");
// }
// else
// {
//     printf("i am not 11");
// }

// write a  program to find out weather a student is pass or fail if it requires 40% and at least 33% in each subject to paas assume 3 subject and take make as an input from the user

// int c_language;
// int fundamental;
// int math;
// float total;



// printf("enter marks of c language\n");
// scanf("%d",&c_language);

// printf("enter marks of fundamental\n");
// scanf("%d",&fundamental);

// printf("enter marks of math\n");
// scanf("%d",&math);
// total=(c_language+fundamental+math)/3;

// if ((total<40 ) || fundamental<33 || c_language<33 || math<33)
// {
//     printf("you are faill %f\n",total);
// }
// else {
// printf("you are fass %f\n",total);
// }

// float tax = 0,income;
// printf("enter the income");
// scanf("%f",&income);

// if (income >= 250000 && income <= 5000000);

// {
//     tax = tax+ 0.05 *(income - 250000);
// }

// if (income >= 5000000 && income <= 10000000);

// {
//     tax= tax +0.20*(income-5000000);
// }

// if (income >= 10000000);

// {
//     tax= tax + 0.30 * (income-10000000);
// }
// printf("you tax is paid to be to the gov is :%f\n",tax);


// char cas;
// printf("enter the charcter");
// scanf("%c",&cas);

// if (cas<=122 && cas>=97  )
// {
//     printf(" %cit is lowercase",cas);
// }
// else{
//     printf("%cit is not lower case",cas);
// }


// Q 6 for greater four number 

// int a,b,c,d;
//  printf("enter the number");
//  scanf("%d %d %d %d",&a,&b,&c,&d);

// if (a>b)
//  {
//     if (a>c)
//     {
//        if (a>d)
//        {
//         printf("%d : is big",b);
//        }
//        else
//        {
//         printf("%dis big ",d );
//        }

//     }
 
//  }
//  else if(b>c) 
//  {
// if (b>d)
// {
//     printf("%d is big ",b);
// }
//  else
//        {
//         printf("%dis big ",d );
//        }


//  }
//  else if (c>d)
//  {
//    printf("%d is big ", c);
//  }
//  else
//  {
//     printf("%d is big ", d);
//  }

// Q for the leap year or not 

// int year ;

// printf("enter the year ");s
// scanf("%d",&year);

// if (year%400==0)
// {
//     printf("%d\n :year is leap year ",year);
// }
// else if(year%100==0)
// {
//     printf("%d\n year is leap year",year);
// }
// else if (year%4==0)
// {
//     printf("%d\n year is leap ",year);
// }
// else{
//     printf("%d \n year is non leap year",year);
// }


 

 
 




 
return 0;
}
