# include<stdio.h>
int main()
{
// printf("hello\n");
// printf("would! \n");
// int a=1;
// printf("%d\n ",a);
// a++;
// printf("%d\n ",a);
// a++;
// printf("%d\n ",a);
// a++;
// printf("%d\n ",a);
// a++;
// printf("%d\n ",a);
// a++;
// printf("%d\n ",a);

// int b;
// printf("enter the value");
// scanf("%d",&b);
// while (b<=20)
// {
//     printf("%d\n",b);
//     b++;
// }

// int i=0;
// printf("enter the value \n");
// scanf("%d",&i);

// while (i<=20){

//     if (i>=10){
//     printf("%d\n",i);
//     }    
//      i++;    
    
// }

//  int x=0;
//  do
//  {
//     printf("the value is %d \n",x);
//     x++;
//  } while (x<=4);
 
//  for ( int i =0; i <=20; i++)
//  {
//     printf("the number is %d\n00",i);
//  }
 
//  int n;
//  printf("enter the value of n is ");
//  scanf("%d",&n);
 
//  for (int i=n; i;i--)
//  {
//     printf("the number is %d\n",i);
//     if (i<=8)
    // {
    //     break;
    // }
    // }
    
 
  



return 0;
}